import React, { useState, useEffect } from 'react';
import './TextEditor.css'; // Import CSS file for styling
import mammoth from 'mammoth';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTable } from '@fortawesome/free-solid-svg-icons';

const TextEditor = () => {
  const [content, setContent] = useState('');
 
  const [wordCount, setWordCount] = useState(0);
  const [showTableDialog, setShowTableDialog] = useState(false);
  const [tableDimensions, setTableDimensions] = useState({ rows: 2, columns: 2 });

  useEffect(() => {
    // Update word count whenever content changes
    const words = content.trim().split(/\s+/);
    setWordCount(words.length);
  }, [content]);





  const handleContentChange = (e) => {
    // Check if e.target.value is defined before calling trim()
    const newContent = e.target.value ? e.target.value.trim() : '';
    setContent(newContent);
  };



  const handleDrop = (e) => {
    e.preventDefault();

    const text = e.dataTransfer.getData('text/plain');
    const { clientX, clientY } = e;

    // Find the element where the drop occurred
    const range = document.caretRangeFromPoint(clientX, clientY);
    const parentDiv = document.querySelector('.editing-area');

    if (range) {
        // Get the current content and position where to insert the dropped text
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);

        // Insert the dragged text at the current caret position
        document.execCommand('insertText', false, text);

        // Update the content state with the modified HTML
        setContent(parentDiv.innerHTML);
    }
};


  const handleInsertTable = () => {
    // Show the table dialog
    setShowTableDialog(true);
  };

  const tableDialog = (
    <div className="table-dialog" style={{ display: showTableDialog ? 'block' : 'none' }}>
      <input
        type="number"
        value={tableDimensions.rows}
        onChange={(e) => setTableDimensions({ ...tableDimensions, rows: parseInt(e.target.value) })}
      />
      <span> x </span>
      <input
        type="number"
        value={tableDimensions.columns}
        onChange={(e) => setTableDimensions({ ...tableDimensions, columns: parseInt(e.target.value) })}
      />
      <button onClick={() => {
        setShowTableDialog(false);
        insertTable(tableDimensions.rows, tableDimensions.columns);
      }}>Insert Table</button>
    </div>
  );

  // Function to insert table with specified dimensions
  const insertTable = (rows, columns) => {
    let tableHTML = '<table border="1"><tbody>';
    // Adding rows and columns
    for (let i = 0; i < rows; i++) {
      tableHTML += '<tr>';
      for (let j = 0; j < columns; j++) {
        tableHTML += '<td></td>';
      }
      tableHTML += '</tr>';
    }
    tableHTML += '</tbody></table>';
    // Update content state with the inserted table
    setContent(content + tableHTML);
  };


  return (
    <div className="text-editor">
      {/* Editor Name */}
      <h1 className="editor-name">LOKI Editor</h1>

      {/* Toolbar */}
      <div className="toolbar">

        {/* Button to insert table */}
<button onClick={handleInsertTable}>
          <FontAwesomeIcon icon={faTable} />
        </button>      </div>
        {tableDialog}
      {/* Word Count */}
      <div className="word-count">Word Count: {wordCount}</div>

      <div
        className="editing-area"
        contentEditable="true"
        onDrop={handleDrop}

        spellCheck="Flase" // Add this line to enable spell check
        dangerouslySetInnerHTML={{ __html: content }}
        onInput={handleContentChange}
        placeholder="Start typing..."
        aria-label="Text Editor"
      />
    </div>
  );
};

export default TextEditor;
  