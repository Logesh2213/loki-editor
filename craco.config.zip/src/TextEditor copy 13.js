import React, { useState } from 'react';
import './TextEditor.css'; // Import CSS file for styling
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTable } from '@fortawesome/free-solid-svg-icons';

const TextEditor = () => {
  const [content, setContent] = useState('');
  const [showTableDialog, setShowTableDialog] = useState(false);
  const [tableDimensions, setTableDimensions] = useState({ rows: 2, columns: 2 });

  const handleContentChange = (e) => {
    setContent(e.target.innerHTML);
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text/html');
    document.execCommand('insertHTML', false, pastedData);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const text = e.dataTransfer.getData('text/plain');
    const { clientX, clientY } = e;
    const targetElement = document.elementFromPoint(clientX, clientY);
    const parentDiv = document.querySelector('.editing-area');
    const range = document.createRange();
    const sel = window.getSelection();

    range.setStart(targetElement, 0);
    range.collapse(true);
    sel.removeAllRanges();
    sel.addRange(range);

    document.execCommand('insertText', false, '\n' + text); // Insert new line before pasted text
    setContent(parentDiv.innerHTML);
  };

  const formatText = (format, value = null) => {
    document.execCommand(format, false, value);
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = function (event) {
      const img = new Image();
      img.src = event.target.result;
      img.onload = function () {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        const dataURL = canvas.toDataURL('image/png');

        // Create a new image element
        const newImage = document.createElement('img');
        newImage.src = dataURL;

        // Set maximum width and height for the image
        newImage.style.maxWidth = '100%'; // Adjust this value as needed
        newImage.style.maxHeight = '200px'; // Adjust this value as needed

        // Append the image to the editing area
        const editingArea = document.querySelector('.editing-area');
        editingArea.appendChild(newImage);

        // Update the state to reflect the new content
        setContent(editingArea.innerHTML);
      };
    };

    reader.readAsDataURL(file);
  };

  // Function to handle table insertion
  const handleInsertTable = () => {
    // Show the table dialog
    setShowTableDialog(true);
  };

  // JSX for the table dialog/submenu
  const tableDialog = (
    <div className="table-dialog" style={{ display: showTableDialog ? 'block' : 'none' }}>
      <input
        type="number"
        value={tableDimensions.rows}
        onChange={(e) => setTableDimensions({ ...tableDimensions, rows: parseInt(e.target.value) })}
      />
      <span> x </span>
      <input
        type="number"
        value={tableDimensions.columns}
        onChange={(e) => setTableDimensions({ ...tableDimensions, columns: parseInt(e.target.value) })}
      />
      <button onClick={() => {
        setShowTableDialog(false);
        insertTable(tableDimensions.rows, tableDimensions.columns);
      }}>Insert Table</button>
    </div>
  );

  // Function to insert table with specified dimensions
  const insertTable = (rows, columns) => {
    let tableHTML = '<table border="1"><tbody>';
    // Adding rows and columns
    for (let i = 0; i < rows; i++) {
      tableHTML += '<tr>';
      for (let j = 0; j < columns; j++) {
        tableHTML += '<td></td>';
      }
      tableHTML += '</tr>';
    }
    tableHTML += '</tbody></table>';
    // Update content state with the inserted table
    setContent(content + tableHTML);
  };

  return (
    <div className="text-editor">
      {/* Editor Name */}
      <h1 className="editor-name">LOKI Editor</h1>

      <div className="toolbar">
        {/* Table button */}
        <button onClick={handleInsertTable}>
          <FontAwesomeIcon icon={faTable} />
        </button>
      </div>

      {/* Table dimensions */}
      {tableDialog}

      {/* Editing area */}
      <div
        className="editing-area"
        contentEditable="true"
        onPaste={handlePaste}
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
        dangerouslySetInnerHTML={{ __html: content }}
        onInput={handleContentChange}
        placeholder="Start typing..."
      />
    </div>
  );
};

export default TextEditor;
