import React, { useState, useEffect } from 'react';
import './TextEditor.css'; // Import CSS file for styling
import mammoth from 'mammoth';
import { Document } from 'html-docx-js/dist/html-docx';

const TextEditor = () => {
  const [content, setContent] = useState('');
  const [selectedFontFamily, setSelectedFontFamily] = useState('Arial');
  const [selectedFontSize, setSelectedFontSize] = useState('medium');
  const [wordCount, setWordCount] = useState(0);

  useEffect(() => {
    // Update word count whenever content changes
    const words = content.trim().split(/\s+/);
    setWordCount(words.length);
  }, [content]);


  const handleFileUpload = (file) => {
    if (file.type.startsWith('image/')) {
      // Handle image upload
      handleImageUpload(file);
    } else if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      // Handle DOCX file upload
      handleDocxUpload(file);
    } else {
      alert('Unsupported file format');
    }
  };
  
  const handleDocxUpload = (file) => {
    const reader = new FileReader();
  
    reader.onload = function (event) {
      const arrayBuffer = reader.result;
      mammoth.convertToHtml({ arrayBuffer })
        .then(result => {
          setContent(result.value);
        })
        .catch(error => {
          console.error('Error converting DOCX to HTML:', error);
          alert('Error converting DOCX to HTML');
        });
    };
  
    reader.readAsArrayBuffer(file);
  };
  






  const handleContentChange = (e) => {
    // Check if e.target.value is defined before calling trim()
    const newContent = e.target.value ? e.target.value.trim() : '';
    setContent(newContent);
  };

  const formatText = (format, value = null) => {
    document.execCommand(format, false, value);
  };

  const handleTextColorChange = (color) => {
    formatText('foreColor', color);
  };

  const handleHighlightColorChange = (color) => {
    const span = document.createElement('span');
    span.style.backgroundColor = color;
    const selection = window.getSelection();
    if (selection.rangeCount > 0) {
      const range = selection.getRangeAt(0).cloneRange();
      range.surroundContents(span);
      selection.removeAllRanges();
      selection.addRange(range);
    }
  };

  const handleInsertLink = () => {
    const url = prompt('Enter the URL:');
    if (url) {
      formatText('createLink', url);
    }
  };



  const handleClearFormatting = () => {
    formatText('removeFormat');
  };

  const handleIndent = () => {
    formatText('indent');
  };

  const handleOutdent = () => {
    formatText('outdent');
  };

  const handleUndo = () => {
    document.execCommand('undo');
  };

  const handleRedo = () => {
    document.execCommand('redo');
  };

  const handleAlignment = (alignment) => {
    formatText(`justify${alignment}`);
  };

  const handleFontFamilyChange = (e) => {
    setSelectedFontFamily(e.target.value);
    formatText('fontName', e.target.value);
  };

  const handleFontSizeChange = (e) => {
    setSelectedFontSize(e.target.value);
    formatText('fontSize', e.target.value);
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = function (event) {
      const img = new Image();
      img.src = event.target.result;
      img.onload = function () {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        const dataURL = canvas.toDataURL('image/png');

        const newImage = document.createElement('img');
        newImage.src = dataURL;
        newImage.style.maxWidth = '100%';
        newImage.style.maxHeight = '200px';

        const editingArea = document.querySelector('.editing-area');
        editingArea.appendChild(newImage);

        setContent(editingArea.innerHTML);
      };
    };

    reader.readAsDataURL(file);
  };

  return (
    <div className="text-editor">
      {/* Editor Name */}
      <h1 className="editor-name">LOKI Editor</h1>

      {/* Toolbar */}
      <div className="toolbar">
      <input type="file" accept="image/*,.docx" onChange={(e) => handleFileUpload(e.target.files[0])} title="Upload Image or DOCX file" aria-label="Upload Image or DOCX file" />

        <button onClick={() => formatText('bold')} aria-label="Bold"><strong>B</strong></button>
        <button onClick={() => formatText('italic')} aria-label="Italic"><em>I</em></button>
        <button onClick={() => formatText('underline')} aria-label="Underline"><u>U</u></button>
        <button onClick={() => formatText('insertOrderedList')} aria-label="Numbered List"><span role="img" aria-label="Numbered List">1️⃣</span></button>
        <button onClick={() => formatText('insertUnorderedList')} aria-label="Bulleted List"><span role="img" aria-label="Bulleted List">•</span></button>
        <button onClick={() => handleAlignment('Left')} aria-label="Align Left"><span role="img" aria-label="Align Left">🡄</span></button>
        <button onClick={() => handleAlignment('Center')} aria-label="Align Center"><span role="img" aria-label="Align Center">🡆</span></button>
        <button onClick={() => handleAlignment('Right')} aria-label="Align Right"><span role="img" aria-label="Align Right">🡆</span></button>
        <button onClick={() => formatText('insertHorizontalRule')} aria-label="Horizontal Rule">HR</button>
        <button onClick={() => formatText('insertHTML', '<br />')} aria-label="Line Break">Line Break</button>
        <button onClick={() => formatText('strikeThrough')} aria-label="Strikethrough">Strikethrough</button>
        <button onClick={() => formatText('subscript')} aria-label="Subscript">Subscript</button>
        <button onClick={() => formatText('superscript')} aria-label="Superscript">Superscript</button>
        <input type="color" onChange={(e) => handleTextColorChange(e.target.value)} title="Text Color" aria-label="Text Color" />
        <input type="color" onChange={(e) => handleHighlightColorChange(e.target.value)} title="Highlight Color" aria-label="Highlight Color" />
        <button onClick={handleInsertLink} aria-label="Insert Link">Link</button>
        <button onClick={handleClearFormatting} aria-label="Clear Formatting">Clear Formatting</button>
        <button onClick={handleIndent} aria-label="Indent">Indent</button>
        <button onClick={handleOutdent} aria-label="Outdent">Outdent</button>
        <button onClick={handleUndo} aria-label="Undo">Undo</button>
        <button onClick={handleRedo} aria-label="Redo">Redo</button>
        <div>
          <label htmlFor="fontFamily">Font Family:</label>
          <select id="fontFamily" value={selectedFontFamily} onChange={handleFontFamilyChange}>
            <option value="Arial">Arial</option>
            <option value="Verdana">Verdana</option>
            <option value="Tahoma">Tahoma</option>
            <option value="Helvetica">Helvetica</option>
            <option value="Times New Roman">Times New Roman</option>
            <option value="Georgia">Georgia</option>
            <option value="Courier New">Courier New</option>
            <option value="Courier">Courier</option>
            <option value="Lucida Console">Lucida Console</option>
            <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
            <option value="Palatino Linotype">Palatino Linotype</option>
            <option value="Trebuchet MS">Trebuchet MS</option>
            <option value="Arial Black">Arial Black</option>
            <option value="Impact">Impact</option>
            <option value="Comic Sans MS">Comic Sans MS</option>
            {/* Add more font families as needed */}
          </select>

          <label htmlFor="fontSize">Font Size:</label>
          <select id="fontSize" value={selectedFontSize} onChange={handleFontSizeChange}>
            <option value="x-small">Extra Small</option>
            <option value="small">Small</option>
            <option value="medium">Medium</option>
            <option value="large">Large</option>
            <option value="x-large">Extra Large</option>
          </select>
        </div>
        <input type="file" accept="image/*" onChange={handleImageUpload} title="Upload Image" aria-label="Upload Image" />
      </div>

      {/* Word Count */}
      <div className="word-count">Word Count: {wordCount}</div>

      <div
        className="editing-area"
        contentEditable="true"
        spellCheck="Flase" // Add this line to enable spell check
        dangerouslySetInnerHTML={{ __html: content }}
        onInput={handleContentChange}
        placeholder="Start typing..."
        aria-label="Text Editor"
      />
    </div>
  );
};

export default TextEditor;
