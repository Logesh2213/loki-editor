import React from 'react';

const HeaderFooterOptions = ({ onClose }) => {
    return (
        <div className="header-footer-options">
            <div className="header-options">
                Header Options
            </div>
            <div className="footer-options">
                Footer Options
            </div>
            <button onClick={onClose}>Close</button>
        </div>
    );
};

export default HeaderFooterOptions;
