import React, { useState } from 'react';
import './TextEditor.css'; // Import CSS file for styling

const TextEditor = () => {
  const [content, setContent] = useState('');

  const handleContentChange = (e) => {
    setContent(e.target.value);
  };

  const formatText = (format, value = null) => {
    document.execCommand(format, false, value);
  };

  const handleColorChange = (e) => {
    const color = e.target.value;
    formatText('foreColor', color);
  };

  return (
    <div className="text-editor">
      {/* Toolbar */}
      <div className="toolbar">
        <button onClick={() => formatText('bold')}><strong>B</strong></button>
        <button onClick={() => formatText('italic')}><em>I</em></button>
        <button onClick={() => formatText('underline')}><u>U</u></button>
        <button onClick={() => formatText('insertOrderedList')}><span role="img" aria-label="Numbered List">1️⃣</span></button>
        <button onClick={() => formatText('insertUnorderedList')}><span role="img" aria-label="Bulleted List">•</span></button>
        <button onClick={() => formatText('justifyLeft')}><span role="img" aria-label="Align Left">🡄</span></button>
        <button onClick={() => formatText('justifyCenter')}><span role="img" aria-label="Align Center">🡆</span></button>
        <button onClick={() => formatText('justifyRight')}><span role="img" aria-label="Align Right">🡆</span></button>
        <button onClick={() => formatText('insertHorizontalRule')}>HR</button>
        <button onClick={() => formatText('insertHTML', '<br />')}>Line Break</button>
        <button onClick={() => formatText('strikeThrough')}>Strikethrough</button>
        <button onClick={() => formatText('subscript')}>Subscript</button>
        <button onClick={() => formatText('superscript')}>Superscript</button>
        <input type="color" onChange={handleColorChange} title="Text Color" />
        {/* Add more buttons for additional formatting options */}
      </div>

      {/* Editing area */}
      <div
        className="editing-area"
        contentEditable="true"
        dangerouslySetInnerHTML={{ __html: content }}
        onInput={handleContentChange}
        placeholder="Start typing..."
      />
    </div>
  );
};

export default TextEditor;
