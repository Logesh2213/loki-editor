import React, { useState } from 'react';
import './TextEditor.css'; // Import CSS file for styling

const TextEditor = () => {
  // State to manage the content of the editor
  const [content, setContent] = useState('');

  // Event handler to update content when typing
  const handleContentChange = (e) => {
    setContent(e.target.value);
  };

  // Function to format selected text
  const formatText = (format) => {
    document.execCommand(format, false, null); // Execute command for formatting
  };

  return (
    <div className="text-editor">
      {/* Toolbar */}
      <div className="toolbar">
        {/* Bold button */}
        <button onClick={() => formatText('bold')}>
          <strong>B</strong>
        </button>
        {/* Italic button */}
        <button onClick={() => formatText('italic')}>
          <em>I</em>
        </button>
        {/* Underline button */}
        <button onClick={() => formatText('underline')}>
          <u>U</u>
        </button>
      </div>

      {/* Editing area */}
      <div
        className="editing-area"
        contentEditable="true"
        dangerouslySetInnerHTML={{ __html: content }}
        onInput={handleContentChange}
        placeholder="Start typing..."
      />
    </div>
  );
};

export default TextEditor;
