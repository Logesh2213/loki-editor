import React, { useState } from 'react';
import './TextEditor.css'; // Import CSS file for styling

const TextEditor = () => {
  const [content, setContent] = useState('');

  const handleContentChange = (e) => {
    setContent(e.target.value);
  };

  const formatText = (format, value = null) => {
    document.execCommand(format, false, value);
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
  
    reader.onload = function (event) {
      const img = new Image();
      img.src = event.target.result;
      img.onload = function () {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        const dataURL = canvas.toDataURL('image/png');
  
        // Create a new image element
        const newImage = document.createElement('img');
        newImage.src = dataURL;
  
        // Set maximum width and height for the image
        newImage.style.maxWidth = '100%'; // Adjust this value as needed
        newImage.style.maxHeight = '200px'; // Adjust this value as needed
  
        // Append the image to the editing area
        const editingArea = document.querySelector('.editing-area');
        editingArea.appendChild(newImage);
        
        // Update the state to reflect the new content
        setContent(editingArea.innerHTML);
      };
    };
  
    reader.readAsDataURL(file);
  };
  
  

  return (
    <div className="text-editor">
      {/* Editor Name */}
      <h1 className="editor-name">LOKI Editor</h1>

      {/* Toolbar */}
      <div className="toolbar">
        <button onClick={() => formatText('bold')}><strong>B</strong></button>
        <button onClick={() => formatText('italic')}><em>I</em></button>
        <button onClick={() => formatText('underline')}><u>U</u></button>
        <button onClick={() => formatText('insertOrderedList')}><span role="img" aria-label="Numbered List">1️⃣</span></button>
        <button onClick={() => formatText('insertUnorderedList')}><span role="img" aria-label="Bulleted List">•</span></button>
        <button onClick={() => formatText('justifyLeft')}><span role="img" aria-label="Align Left">🡄</span></button>
        <button onClick={() => formatText('justifyCenter')}><span role="img" aria-label="Align Center">🡆</span></button>
        <button onClick={() => formatText('justifyRight')}><span role="img" aria-label="Align Right">🡆</span></button>
        <button onClick={() => formatText('insertHorizontalRule')}>HR</button>
        <button onClick={() => formatText('insertHTML', '<br />')}>Line Break</button>
        <button onClick={() => formatText('strikeThrough')}>Strikethrough</button>
        <button onClick={() => formatText('subscript')}>Subscript</button>
        <button onClick={() => formatText('superscript')}>Superscript</button>
        <input type="color" onChange={(e) => formatText('foreColor', e.target.value)} title="Text Color" />
        <input type="file" accept="image/*" onChange={handleImageUpload} title="Upload Image" />
        {/* Add more buttons for additional formatting options */}
        <input type="color" onChange={(e) => handleTextColorChange(e.target.value)} title="Text Color" />
        <input type="color" onChange={(e) => handleHighlightColorChange(e.target.value)} title="Highlight Color" />
      </div>

      {/* Editing area */}
      <div
        className="editing-area"
        contentEditable="true"
        dangerouslySetInnerHTML={{ __html: content }}
        onInput={handleContentChange}
        placeholder="Start typing..."
      />
    </div>
  );
};

export default TextEditor;